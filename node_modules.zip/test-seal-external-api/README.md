# test-seal-external-api
Project for automated test on the seal external api
